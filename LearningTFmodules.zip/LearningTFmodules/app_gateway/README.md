## Terraform 12 Module for creating Azure Application gateway

Modules for creating Resource group, Azure VNET, Azure Virtual Machine and Azure application gateway


## Assumptions
 
* Basic knowledge of Terraform
* Good knowledge of the resources these modules are deploying
* Azure is configured for terraform:https://geekdudes.wordpress.com/2018/01/22/configuring-terraform-for-azure/

# Creating resource group:

### Terraform Module: azure_resource_group

Location:'terraform/modules/rg` folder
Module for creating Azure resource group

## Inputs

Inputs are defined in `terraform/modules/rg/variables.tf` file

| Name | Type | Default | Required | Description |
|------|------|-------|--------|-----------|
| `resource_group_name`  | `string` | `none` | `yes` | Azure Resource group name |
| `resource_group_location`  | `string` | `none` | `yes` | Azure Resource group location | 

## Outputs

Outputs can be found defined in the `terraform/modules/rg/outputs.tf` file 

| Name | Description |
|------|-----------|
| `resource_group_name`  | Azure Resource group name |
| `resource_group_location`  | Azure Resource group location |

## How To Use

```
module "rg" {
source = "./../../rg"
resource_group_name = var.resource_group_name
resource_group_location=var.resource_group_location
}
```

# Creating Virtual Network:

### Terraform Module: azure-vnet

Location:`terraform/modules/vnet` folder
Module for creating Azure VNET with options for adding multiple subnets, multiple security group and multiple route tables

## Inputs

Inputs are defined in `terraform/modules/vnet/*vars.tf` files

| Name | Type | Default | Required | Description |
|------|------|:-------:|:--------:|:-----------:|
| `environment_name`  | `string` | `none` | `yes` | This name will be prefixed to each resource |
| `environment_type`  | `string` | `none` | `yes` | Either `production` or `testing` or `development` |
| `tags_global`  | `map` | `none` | `yes` | Map/Dictionary containing all global tags in the environment, those tags will be added to each resource |
| `tags_module`  | `map` | `none` | `yes` | Map/Dictionary containing all module related tags, those tags will be added to each resource in the module |
| `cidr_block`  | `string` | `10.10.0.0/19` | `yes` | The CIDR block to be used by the VNET. Please provide /19 CIDR blocks. Other ranges will not work. |
| `enable_wan_subnet`  | `bool ` | `true` | `no` | Controls wether the WAN subnets will be deployed or not |
| `enable_dmz_subnet`  | `bool ` | `true ` | `no ` | Controls wether the DMZ subnets will be deployed or not  |
| `enable_vdi_subnet`  | `bool ` | `true ` | `no ` | Controls wether the VDI subnets will be deployed or not  |
| `enable_infrastructure_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Infrastructure Services subnets will be deployed or not  |
| `enable_infrastructure_db_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Infrastructure DB Services subnets will be deployed or not  |
| `enable_production_app_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Production App Services subnets will be deployed or not  |
| `enable_production_db_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Production DB Services subnets will be deployed or not  |
| `enable_acceptance_app_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Acceptance App Services subnets will be deployed or not  |
| `enable_acceptance_db_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Acceptance DB Services subnets will be deployed or not  |
| `enable_test_app_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Test App Services subnets will be deployed or not  |
| `enable_test_db_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Test DB Services subnets will be deployed or not  |
| `enable_development_app_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Development App Services subnets will be deployed or not  |
| `enable_development_db_services_subnet`  | `bool ` | `true ` | `no ` | Controls wether the Development DB Services subnets will be deployed or not  |
| `resource_group_name`  | `string ` | `true ` | `yes ` | Resource group name (output of `rg` module)|
|  `resource_group_location`  | `string ` | `true ` | `yes ` | Resource group location (output of `rg` module)


## Outputs

Outputs can be found defined in the  `terraform/modules/vnet/*.out.tf` file
 
| Name | Type | Description |
|------|------|-------------|
| `vnet_id` | `string` | This is the VNET ID |
| `cidr_block` | `string` | The CIDR block of the VNET |
| `environment_name` | `string` | Passthrough output from the `environment_name` input. |
| `environment_type` | `string` | Passthrough output from the `environment_type` input. |
| `route_tables_id_default` | `string` | The ID of the route table created by default on VNET creation |
| `route_tables_id_wan` | `string` | WAN route table ID |
| `route_tables_id_dmz` | `string` | DMZ route table ID |
| `route_tables_id_vdi` | `string` | VDI route table ID |
| `route_tables_id_infrastructure_services` | `string` | Infrastructure services route table ID |
| `route_tables_id_infrastructure_db_services` | `string` | Infrastructure DB services route table ID |
| `route_tables_id_production_app_services` | `string` | Production App services route table ID |
| `route_tables_id_production_db_services` | `string` | Production DB services route table ID |
| `route_tables_id_acceptance_app_services` | `string` | Acceptance App services route table ID |
| `route_tables_id_acceptance_db_services` | `string` | Acceptance DB services route table ID |
| `route_tables_id_test_app_services` | `string` | Test App services route table ID |
| `route_tables_id_test_db_services` | `string` | Test DB services route table ID |
| `route_tables_id_development_app_services` | `string` | Development App services route table ID |
| `route_tables_id_development_db_services` | `string` | Development DB services route table ID |
| `security_groups_id_default` | `string` | The ID of the security group created by default on VNET creation |
| `security_groups_id_global` | `string` | Global security group ID |
| `security_groups_id_wan` | `string` | WAN security group ID |
| `security_groups_id_dmz` | `string` | DMZ security group ID |
| `security_groups_id_vdi` | `string` | VDI security group ID |
| `security_groups_id_infrastructure_services` | `string` | Infrastructure Services security group ID |
| `security_groups_id_infrastructure_db_services` | `string` | Infrastructure DB Services security group ID |
| `security_groups_id_production_app_services` | `string` | Production App Services security group ID |
| `security_groups_id_production_db_services` | `string` | Production DB Services security group ID |
| `security_groups_id_acceptance_app_services` | `string` | Acceptance App Services security group ID |
| `security_groups_id_acceptance_db_services` | `string` | Acceptance DB Services security group ID |
| `security_groups_id_test_app_services` | `string` | Test App Services security group ID |
| `security_groups_id_test_db_services` | `string` | Test DB Services security group ID |
| `security_groups_id_development_app_services` | `string` | Development App Services security group ID |
| `security_groups_id_development_db_services` | `string` | Development DB Services security group ID |
| `subnets_id_wan` | `list` | WAN subnet IDs |
| `subnets_cidr_blocks_wan` | `list` | WAN subnet CIDR blocks |
| `subnets_id_dmz` | `list` | DMZ subnet IDs |
| `subnets_cidr_blocks_dmz` | `list` | DMZ subnet CIDR blocks |
| `subnets_id_vdi` | `list` | VDI subnet IDs |
| `subnets_cidr_blocks_vdi` | `list` | VDI subnet CIDR blocks |
| `subnets_id_infrastructure_services` | `list` | Infrastructure Services subnet IDs |
| `subnets_cidr_blocks_infrastructure_services` | `list` | Infrastructure Services subnet CIDR blocks |
| `subnets_id_infrastructure_db_services` | `list` | Infrastructure DB Services subnet IDs |
| `subnets_cidr_blocks_infrastructure_db_services` | `list` | Infrastructure DB Services subnet CIDR blocks |
| `subnets_id_production_app_services` | `list` | Production App Services subnet IDs |
| `subnets_cidr_blocks_production_app_services` | `list` | Production App Services subnet CIDR blocks |
| `subnets_id_production_db_services` | `list` | Production DB Services subnet IDs |
| `subnets_cidr_blocks_production_db_services` | `list` | Production DB Services subnet CIDR blocks |
| `subnets_id_acceptance_app_services` | `list` | Acceptance App Services subnet IDs |
| `subnets_cidr_blocks_acceptance_app_services` | `list` | Acceptance App Services subnet CIDR blocks |
| `subnets_id_acceptance_db_services ` | `list` | Acceptance DB Services subnet IDs |
| `subnets_cidr_blocks_acceptance_db_services` | `list` | Acceptance DB Services subnet CIDR blocks |
| `subnets_id_test_app_services ` | `list` | Test App Services subnet IDs |
| `subnets_cidr_blocks_test_app_services` | `list` | Test App Services subnet CIDR blocks |
| `subnets_id_test_db_services ` | `list` | Test DB Services subnet IDs |
| `subnets_cidr_blocks_test_db_services` | `list` | Test DB Services subnet CIDR blocks |
| `subnets_id_development_app_services ` | `list` | Development App Services subnet IDs |
| `subnets_cidr_blocks_development_app_services` | `list` | Development App Services subnet CIDR blocks |
| `subnets_id_development_db_services ` | `list` | Development DB Services subnet IDs |
| `subnets_cidr_blocks_development_db_services` | `list` | Development DB Services subnet CIDR blocks |
| `region_name` | `string` | The AZURE region where this VNET is deployed at (It's resource group location) |

## How To Use

* Edit `terraform/modules/vnet/example/main.tf` and change path for all modules to reflect your file structure
* Edit `terraform/modules/vnet/example/variables.tf` and change resource group name, location, environment name
* Change directory to `terraform/VNET/modules/vnet/example` and run  `terraform init && terraform apply` 

Bellow is example of `terraform/modules/vnet/example/main.tf`:

```
# Resource group

module "rg" {

source                                   = "./../../rg"
resource_group_name                      = var.resource_group_name
resource_group_location                  = var.resource_group_location
}

# VNET  

module azure_vnet {
source                                   = "./../../vnet"
environment_name                         = var.environment_name
cidr_block                               = "10.11.96.0/19"
dns_servers                              = [
    "8.8.8.8",
    "8.8.4.4",
    
  ]
resource_group_name                      = var.resource_group_name
resource_group_location                  = var.resource_group_location
enable_wan_subnet                        = true
enable_dmz_subnet                        = false
enable_vdi_subnet                        = false
enable_infrastructure_services_subnet    = false
enable_infrastructure_db_services_subnet = false
enable_production_app_services_subnet    = false
enable_production_db_services_subnet     = false
enable_acceptance_app_services_subnet    = false
enable_acceptance_db_services_subnet     = false
enable_test_app_services_subnet          = false
enable_test_db_services_subnet           = false
enable_development_app_services_subnet   = false
enable_development_db_services_subnet    = false
}

```

# Creating Azure Key Vault:

### Terraform Module: azure_key_vault

Location:`terraform/modules/vault` folder
Module for creating Azure vault,key and secret

## Inputs

Inputs are defined in `terraform/modules/vault/variables.tf` file


| Name | Type | Default | Required | Description |
|------|------|:-------:|:--------:|:-----------:|
| `azure_tenant_id`  | `string` | `none` | `yes` | Azure Tenant ID|
| `azure_object_id`  | `string` | `none` | `yes` | Azure Object ID |
| `resource_group_name`  | `string` | `none` | `yes` | Resource group name |
| `key_vault_name`  | `string` | `none` | `yes` | Name of Key vault  |
| `environment_name`  | `string` | `none` | `no` | Resource name prefix  |
| `network_acl`  | `string` | `none` | `yes` | Your Public IP, it allows access to Key vault

## Outputs

Outputs can be found defined in the `terraform/modules/vault/outputs.tf` file 


| Name | Description |
|------|-----------|
| `key_vault_url`  | Key vault URL |
| `key_vault_resource_id` | Key Vault ID |
| `key_encryption_key_name`  | Encryption key name |
| `key_encryption_key_version`  | Encryption key version |
| `key_vault_secret_id`  | Vault secret ID |

## How To Use

```
module "azure_key_vault" {
source = "./../../vault"
environment_name=var.environment_name
resource_group_name = module.rg.resource_group_name
resource_group_location = module.rg.resource_group_location
azure_object_id = var.object_application_id
azure_tenant_id = var.azure_tenant_id
key_vault_name = var.key_vault_name
network_acl = ["1.1.1.1/32"]
}
```


# Creating Azure Virtual machine:

### Terraform Module: azure_vm

Location:`terraform/modules/vm` folder
Module for creating Azure Virtual machine, it will use outputs of VNET and Key Vault modules, to place VM in VNET subnet and will use keys from Key Vault in order to encrypt OS disk. It will create number od VM's specified in `number_of_machines` variable, 1 data disk and number of managed disks specified in `number_of_managed_disks` variable, user must choose OS (linux/windows) in `os` variable and populate 
`vm_image_publisher`, `vm_image_offer` and `vm_image_sku` variables accordingly

## Inputs

Inputs are defined in `terraform/modules/vm/variables.tf` file

| Name | Type | Default | Required | Description |
|------|------|:-------:|:--------:|:-----------:|
| `vm_size`  | `string` | `none` | `yes` | Size of VM|
| `vm_image_publisher`  | `string` | `none` | `yes` | vm image vendor |
| `vm_image_offer`  | `string` | `none` | `yes` | vm image vendor's VM offering |
| `key_vault_name`  | `string` | `none` | `yes` | Name of Key vault  |
| `vm_image_sku`  | `string` | `none` | `yes` | An instance of an offer, such as a major release of a distribution. Examples: 18.04-LTS, 2019-Datacenter |
| `vm_image_version`  | `string` | `none` | `yes` | The version number of an image SKU. |
| `vm_admin`  | `string` | `none` | `yes` | VM administrator |
| `vm_password`  | `string` | `none` | `yes` | VM password |
| `vm_name`  | `string` | `none` | `yes` | VM name Azure portal |
| `computer_name`  | `string` | `none` | `yes` | Local/OS VM name |
| `resource_group_name`  | `string` | `none` | `yes` | Resource group name (output of azure_resource_group module) |
| `resource_group_location`  | `string` | `none` | `yes` | Resource group location (output of azure_resource_group module) |
| `encryption`  | `boolean` | `false` | `yes` | Turn on/off OS disk encryption |
| `os`  | `string` | `none` | `yes` | Your Public IP, it allows access to Key vault |
| `ssh_public_key`  | `string` | `none` | `no` | SSH Public key of Linux VM |
| `environment_name`  | `string` | `none` | `no` | Resource name prefix |
| `number_of_machines`  | `integer` | `none` | `yes` | Number of VMs |
| `availability_set_update_domain_count`  | `integer` | `1` | `yes` | Number of domains in availability set |
| `availability_set_fault_domain_count`  | `integer` | `1` | `yes` | Virtual machines in the same fault domain share a common power source and physical network switch |
| `availability_set_managed`  | `booleand` | `true` | `yes` | Availability set name |
| `disk_size`  | `integer` | `none` | `yes` | Disk size in GB |
| `key_vault_url`  | `string` | `none` | `yes` | Key vault URL (output of azure_key_vault module) |
| `key_vault_resource_id`  | `string` | `none` | `yes` | Key Vault resource ID (output of azure_key_vault module) |
| `key_encryption_key_version`  | `string` | `none` | `yes` | Key encryption key version (output of azure_key_vault module) |
| `key_vault_secret_id`  | `string` | `none` | `yes` | Key Value encryption key name (output of azure_key_vault module) |
| `key_encryption_key_name`  | `string` | `none` | `yes` | Key Value encryption key name (output of azure_key_vault module) |
| `key_encryption_key_name`  | `string` | `none` | `yes` | Key Value encryption key name (output of azure_key_vault module) |
| `subnet_id`  | `integer` | `none` | `yes` | Subnet ID (output of azure_vnet module) |
 
## Outputs

Outputs can be found defined in the `terraform/modules/vm/outputs.tf` file 


| Name | Description |
|------|:-----------:|
| `azure_vm_availability_set_id`  | Availability set ID |
| `azure_vm_id` | Azure VM ID |
| `azure_vm_public_ip`  | Azure VM Public IP |
| `azure_managed_disk_id`  | Azure Managed Disk ID" |
| `azure_vm_security_group_id`  | Azure Network security group ID |
| `azure_vm_nic_id`  | Azure Network Interface card ID |
| `azure_nic_ip_configuration`  | Azure VM Network Interface IP Configuration name |

## How To Use

 * Edit `terraform/VM/modules/vm/example/terraform.tfvars` file and set
`azure_application_id = "your id"`
`azure_tenant_id="your id"`

* Edit `terraform/modules/vm/example/main.tf` and change path for all modules to reflect your file structure
* Edit `terraform/modules/vm/example/variables.tf` and change resource group name, location, environment name, key vault name and VM password
* Change directory to `terraform/VM/modules/vm/example` and run  `terraform init && terraform apply` 

Bellow is example of `terraform/modules/vm/example/main.tf` file:

```
# Azure key vault

module "azure_key_vault" {

source                     = "./../../vault"
environment_name           = var.environment_name
resource_group_name        = module.rg.resource_group_name
resource_group_location    = module.rg.resource_group_location
azure_object_id            = var.azure_object_id
azure_tenant_id            = var.azure_tenant_id
key_vault_name             = var.key_vault_name
network_acl                = ["1.1.1.2/32"]
}


# Linux VM

module "azure_vm" {

source                     = "./../../vm"
environment_name           = var.environment_name
key_vault_url              = module.azure_key_vault.key_vault_url
key_vault_resource_id      = module.azure_key_vault.key_vault_resource_id
key_encryption_key_name    = module.azure_key_vault.key_encryption_key_name
key_encryption_key_version = module.azure_key_vault.key_encryption_key_version
key_vault_secret_id        = module.azure_key_vault.key_vault_secret_id
subnet_id                  = module.azure_vnet.vnet_subnet_production_id
resource_group_name        = module.rg.resource_group_name
resource_group_location    = module.rg.resource_group_location
os                         = "linux"
vm_size                    = "Standard_B2ms"
vm_image_publisher         = "OpenLogic"
vm_image_offer             = "Centos"
vm_image_sku               = "7.6"
vm_name                    = "myvm"
vm_admin                   = "ja"
vm_password                = var.vm_password
number_of_machines         = 2
# disk size in GB
disk_size                  = 2
number_of_managed_disks    = 2
# encrypt OS disk
encryption                 = false
}

# Windows VM

module "azure_vm1" {

source                     = "./../../vm"
environment_name           = var.environment_name
key_vault_url              = module.azure_key_vault.key_vault_url
key_vault_resource_id      = module.azure_key_vault.key_vault_resource_id
key_encryption_key_name    = module.azure_key_vault.key_encryption_key_name
key_encryption_key_version = module.azure_key_vault.key_encryption_key_version
key_vault_secret_id        = module.azure_key_vault.key_vault_secret_id
subnet_id                  = module.azure_vnet.vnet_subnet_production_id
resource_group_name        = module.rg.resource_group_name
resource_group_location    = module.rg.resource_group_location
os                         = "windows"
vm_size                    = "Standard_B2ms"
vm_image_publisher         = "MicrosoftWindowsServer"
vm_image_offer             = "WindowsServer"
vm_image_sku               = "2016-Datacenter"
vm_name                    = "myvm2"
vm_admin                   = "ja"
vm_password                = "Passw0rd01234!"
number_of_machines         = 1
disk_size                  = 2
number_of_managed_disks    = 2
encryption                 = false
}
```

# Creating Azure Application Gateway:

### Terraform Module: application_gateway

Location:`terraform/modules/app_gateway` folder
Module for creating Azure Application gateway, if variable
`https` is set to `true`, then Key vault and Self signed certificate is created


## Inputs

Inputs are defined in `terraform/modules/app_gateway/variables.tf` file


| Name | Type | Default | Required | Description |
|------|------|:-------:|:--------:|:-----------:|
| `environment_name`  | `string` | `none` | `yes` | This name will be prefixed to each resource |
| `environment_type`  | `string` | `none` | `yes` | Either `production` or `testing` or `development` |
| `tags_global`  | `map` | `none` | `yes` | Map/Dictionary containing all global tags in the environment, those tags will be added to each resource |
| `tags_module`  | `map` | `none` | `yes` | Map/Dictionary containing all module related tags, those tags will be added to each resource in the module |
| `resource_group_name`  | `string` | `none` | `yes` | Resource group name |
| `resource_group_location`  | `string` | `none` | `yes` | Resource group location |
| `sku`  | `string` | `none` | `yes` | he SKU of the Azure Load Balancer. Accepted values are Basic and Standard. Defaults to Basic.|
| `sku_name`  | `string` | `none` | `yes` | The Name of the SKU to use for this Application Gateway. Possible values are Standard_Small, Standard_Medium, Standard_Large, Standard_v2, WAF_Medium, WAF_Large, and WAF_v2. |
| `tier`  | `string` | `none` | `yes` | The Tier of Azure Application gateway.Possible values are Standard, Standard_v2, WAF and WAF_v2  |
| `capacity`  | `string` | `none` | `yes` | The Capacity of the SKU to use for this Application Gateway - which must be between 1 and 10, optional if autoscale_configuration is set  |
| `subnet_id`  | `string` | `none` | `yes` | Azure VNET subnet |
| `enable_http2`  | `string` | `false` | `yes` | Enable the HTTP/2 protocol |
| `name`  | `string` | `example` | `yes` | Root name applied to all resources. A dynamic name will be generated if none is provided |
| `ssl_cn`  | `list` | `*.dominodatalab.com` | `yes` | List of alternative DNS names identified by the self-signed certificate |
| `disabled_ssl_protocols`  | `string` | `none` | `yes` | Azure VNET subnet |
| `subnet_id`  | `list` | `TLSv1_0, TLSv1_1` | `yes` | List of ssl protocols which should be disabled on this application gateway |
| `health_probe_protocol`  | `string` | `Http` | `yes` | Protocol used to by health probe |
| `health_probe_interval`  | `string` | `30` | `yes` | Interval between two consecutive probes in seconds |
| `health_probe_timeout`  | `string` | `30` | `yes` | Probe is marked as failed if valid response within this timeout period in seconds |
| `health_probe_threshold`  | `string` | `3` | `yes` | Indicates the amount of retries which should be attempted before a pool member is deemed unhealthy |
| `health_probe_path`  | `string` | `/` | `yes` | Path used by health probe |
| `cookie_based_affinity` | `Disabled` | `yes` | Specify Enabled or Disabled. Controls cookie-based session affinity to backend pool members |
|`enable_connection_draining`  | `string` | `false` | `yes` | Enable connection draining to change members within a backend pool without disruption |
|`connection_drain_timeout`  | `string` | `300` | `yes` | Number of seconds to wait before for active connections to drain out of a removed backend pool member |
|`https`  | `string` | `false` | `yes` | If `true` additional HTTPS listeners and self signed certificate will be created |
|`targets`  | `list` | `none` | `yes` | List of NIC IDs configuration |
 
## Local variables
Local variables can be found defined in the `terraform/modules/app_gateway/locals.tf` file 

| Name | Type | Default | Required | Description |
|------|------|:-------:|:--------:|:-----------:|
| `name`  | `string` | `none` | `yes` | name for gateway settings |
| `frontend_ip_configuration_name`  | `string` | `fe-ipconfig` | `yes` | Front end IP configuration name |
| `https_port_name`  | `string` | `none` | `yes` | name for gateway settings |
| `https_port_name `  | `string` | `none` | `https` | IP Config https port name |
| `http_port_name `  | `string` | `none` | `http` | IP Config http port name |
| `https_listener_name`  | `string` | `none` | `https-listener` | IP Config https listener name |
| `http_listener_name `  | `string` | `none` | `http-listener` | IP Config http listener name |
| `backend_address_pool_name `  | `string` | `server-pool` | `http` | IP Config http port name |
| `backend_http_settings_name`  | `string` | `none` | `http-settings` | Backend http settings name |
| `backend_https_settings_name`  | `string` | `none` | `https-settings` | Backend https settings name |
| `certificate_name`  | `string` | `none` | `self-signed-cert` | SSL cert name |
| `health_probe_name`  | `string` | `none` | `healthz` | health probe name |
| `pool_association `  | `number` | `none` | `length(var.targets)` | VM module NIC ID collection lenght |


## Outputs

Outputs can be found defined in the `terraform/modules/app_gateway/outputs.tf` file 


| Name | Description |
|------|-----------|
| `id`  | The ID of the application gateway |
| `backend_address_pool_id` | The ID of the application gateway backend address pool |
| `public_ip`  | The public IP of the application gateway |

## How To Use

```
module "application_gateway" {

source                                   = "../../../modules/app_gateway"
resource_group_name                      = var.resource_group_name
resource_group_location                  = var.resource_group_location
sku_name                                 = "WAF_Medium"
tier                                     = "WAF"
capacity                                 = 1
subnet_id                                = module.azure_vnet.subnets_id_dmz
# you can target the NICs of your VMs to add them to the backend pool for
# this gateway or pass azure_vm module output.
targets                                  = module.azure_vm.azure_vm_nic_id
ip_configuration                         = module.azure_vm.azure_nic_ip_configuration
# https settings
https                                    = true
}
```